"""
utils/data_loader.py
Handles loading, caching, and preprocessing of the Netflix Kaggle dataset.
Automatically downloads the dataset if not present (requires kaggle CLI or manual CSV).
"""

import streamlit as st
import pandas as pd
import numpy as np
import os, re

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "netflix_titles.csv")


@st.cache_data(show_spinner="Loading Netflix dataset…")
def load_data() -> pd.DataFrame:
    """Load and preprocess the Netflix titles dataset."""
    if not os.path.exists(DATA_PATH):
        _download_or_create_sample()

    df = pd.read_csv(DATA_PATH)
    df = _preprocess(df)
    return df


def _download_or_create_sample():
    """Try to download from Kaggle; fall back to a rich synthetic sample."""
    os.makedirs(os.path.dirname(DATA_PATH), exist_ok=True)

    # Try Kaggle CLI
    try:
        import subprocess
        result = subprocess.run(
            ["kaggle", "datasets", "download", "-d", "shivamb/netflix-shows",
             "--unzip", "-p", os.path.dirname(DATA_PATH)],
            capture_output=True, timeout=60
        )
        if result.returncode == 0 and os.path.exists(DATA_PATH):
            return
    except Exception:
        pass

    # Fall back to synthetic data that mirrors the real dataset structure
    _create_synthetic_dataset()


def _create_synthetic_dataset():
    """Generate a realistic synthetic dataset with the same schema."""
    np.random.seed(42)
    n = 2000

    genres_movie  = ["Dramas","Comedies","Action & Adventure","Thrillers",
                     "Romantic Movies","Documentaries","Horror Movies",
                     "International Movies","Stand-Up Comedy","Children & Family Movies"]
    genres_tv     = ["International TV Shows","Crime TV Shows","Kids' TV",
                     "Docuseries","Anime Series","Romantic TV Shows","Reality TV"]
    countries     = ["United States"]*400 + ["India"]*180 + ["United Kingdom"]*90 +
                    ["Japan"]*70 + ["South Korea"]*60 + ["Canada"]*50 +
                    ["Spain"]*40 + ["France"]*38 + ["Germany"]*30 + ["Mexico"]*25 +
                    ["Brazil"]*20 + ["Australia"]*18 + ["Italy"]*15
    ratings_movie = ["R","PG-13","PG","G","NR","TV-MA","TV-14"]
    ratings_tv    = ["TV-MA","TV-14","TV-PG","TV-G","TV-Y","TV-Y7","NR"]
    directors     = ["Rajiv Chilaka","Martin Scorsese","Bong Joon-ho","Alfonso Cuarón",
                     "Christopher Nolan","Ava DuVernay","Spike Lee","Sofia Coppola",
                     "Guillermo del Toro","Greta Gerwig","Park Chan-wook","Unknown"]

    rows = []
    for i in range(n):
        is_movie = np.random.random() < 0.69
        ctype    = "Movie" if is_movie else "TV Show"
        year     = int(np.random.choice(range(2000, 2022),
                       p=np.array([1,1,1,1,2,2,3,4,6,8,10,12,14,16,18,20,22,25,28,30,32,35],
                                  dtype=float) / np.array([1,1,1,1,2,2,3,4,6,8,10,12,14,16,18,20,22,25,28,30,32,35],
                                  dtype=float).sum()))
        added    = f"{np.random.choice(['January','February','March','April','May','June','July','August','September','October','November','December'])} {np.random.randint(1,28)}, {year + np.random.randint(0,3)}"
        country  = np.random.choice(countries)
        g_pool   = genres_movie if is_movie else genres_tv
        n_genres = np.random.randint(1, 4)
        genre    = ", ".join(np.random.choice(g_pool, size=min(n_genres, len(g_pool)), replace=False))
        rating   = np.random.choice(ratings_movie if is_movie else ratings_tv)
        duration = f"{np.random.randint(45,180)} min" if is_movie else f"{np.random.randint(1,5)} Season{'s' if np.random.random()>0.4 else ''}"
        rows.append({
            "show_id":    f"s{i+1}",
            "type":       ctype,
            "title":      f"Title {i+1}",
            "director":   np.random.choice(directors),
            "cast":       "Actor A, Actor B",
            "country":    country,
            "date_added": added,
            "release_year": year,
            "rating":     rating,
            "duration":   duration,
            "listed_in":  genre,
            "description": "Sample description.",
        })

    pd.DataFrame(rows).to_csv(DATA_PATH, index=False)


def _preprocess(df: pd.DataFrame) -> pd.DataFrame:
    """Clean and feature-engineer the raw Netflix CSV."""

    # ── Basic cleaning ───────────────────────────────────────────────────────
    df = df.drop_duplicates(subset="show_id", keep="first")
    df["title"]       = df["title"].fillna("Unknown")
    df["director"]    = df["director"].fillna("Unknown")
    df["cast"]        = df["cast"].fillna("Unknown")
    df["country"]     = df["country"].fillna("Unknown")
    df["rating"]      = df["rating"].fillna("NR")
    df["listed_in"]   = df["listed_in"].fillna("Unknown")
    df["description"] = df["description"].fillna("")

    # ── Date parsing ─────────────────────────────────────────────────────────
    df["date_added"] = pd.to_datetime(df["date_added"].str.strip(), errors="coerce")
    df["year_added"] = df["date_added"].dt.year
    df["month_added"]= df["date_added"].dt.month

    # ── Duration features ────────────────────────────────────────────────────
    df["duration_int"] = df["duration"].str.extract(r"(\d+)").astype(float)
    df["duration_unit"]= df["duration"].str.extract(r"([a-zA-Z]+)")

    # ── Genre list ───────────────────────────────────────────────────────────
    df["genre_list"] = df["listed_in"].str.split(",").apply(
        lambda g: [x.strip() for x in g] if isinstance(g, list) else []
    )
    df["genre_count"] = df["genre_list"].apply(len)

    # ── Primary country ──────────────────────────────────────────────────────
    df["primary_country"] = df["country"].str.split(",").str[0].str.strip()

    # ── Content length category ──────────────────────────────────────────────
    def length_cat(row):
        if row["type"] == "Movie":
            d = row["duration_int"]
            if pd.isna(d):       return "Unknown"
            if d < 60:           return "Short (<60 min)"
            if d < 90:           return "Medium (60–90)"
            if d < 120:          return "Standard (90–120)"
            if d < 150:          return "Long (120–150)"
            return "Extended (>150)"
        else:
            d = row["duration_int"]
            if pd.isna(d):       return "Unknown"
            if d == 1:           return "Mini-series (1)"
            if d <= 3:           return "Short run (2–3)"
            return "Long run (4+)"

    df["length_category"] = df.apply(length_cat, axis=1)

    # ── Mature content flag ──────────────────────────────────────────────────
    df["is_mature"] = df["rating"].isin(["TV-MA","R","NC-17"]).astype(int)

    # ── Is original proxy (date_added within 1 year of release) ─────────────
    df["is_likely_original"] = (
        (df["year_added"].notna()) &
        (df["year_added"] - df["release_year"]).between(0, 1)
    ).astype(int)

    # ── Numeric type label for ML ────────────────────────────────────────────
    df["type_label"] = (df["type"] == "Movie").astype(int)

    return df
