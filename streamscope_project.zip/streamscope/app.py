import streamlit as st

st.set_page_config(
    page_title="StreamScope – Netflix Analyzer",
    page_icon="🎬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── shared CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
    [data-testid="stSidebar"] { background: #141414; }
    [data-testid="stSidebar"] * { color: #e5e5e5 !important; }
    .metric-card { background:#1a1a1a; border-radius:10px; padding:16px 20px;
                   border-left:4px solid #E50914; }
    .metric-card h4 { color:#aaa; font-size:12px; margin:0 0 4px; text-transform:uppercase; }
    .metric-card h2 { color:#fff; font-size:26px; margin:0; }
    .metric-card p  { color:#777; font-size:11px; margin:4px 0 0; }
    .section-title  { color:#E50914; font-weight:700; font-size:13px;
                      letter-spacing:1px; text-transform:uppercase; margin-bottom:4px; }
</style>
""", unsafe_allow_html=True)

from utils.data_loader import load_data

# ── sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🎬 StreamScope")
    st.markdown("Netflix Content Strategy Analyzer")
    st.divider()

    st.markdown("### Filters")
    df_raw = load_data()

    year_min = int(df_raw["release_year"].min())
    year_max = int(df_raw["release_year"].max())
    year_range = st.slider("Release Year", year_min, year_max, (2010, year_max))

    content_type = st.multiselect(
        "Content Type",
        options=["Movie", "TV Show"],
        default=["Movie", "TV Show"],
    )

    all_countries = ["All"] + sorted(df_raw["country"].dropna().str.split(",").explode()
                                     .str.strip().unique().tolist())
    selected_country = st.selectbox("Country", all_countries)

    st.divider()
    st.caption("Dataset: Netflix Movies & TV Shows (Kaggle) · ~8,800 titles")

# ── apply filters ────────────────────────────────────────────────────────────
df = df_raw.copy()
df = df[df["release_year"].between(year_range[0], year_range[1])]
if content_type:
    df = df[df["type"].isin(content_type)]
if selected_country != "All":
    df = df[df["country"].str.contains(selected_country, na=False)]

st.session_state["df"] = df
st.session_state["df_raw"] = df_raw

# ── landing page ─────────────────────────────────────────────────────────────
st.title("🎬 StreamScope")
st.markdown("**Netflix Content Strategy Analyzer** — Explore global trends, genre patterns, and ML-powered insights.")
st.divider()

# KPI row
col1, col2, col3, col4, col5 = st.columns(5)
kpis = [
    ("Total Titles",  f"{len(df):,}",          "after filters"),
    ("Movies",        f"{(df['type']=='Movie').sum():,}",    f"{(df['type']=='Movie').mean()*100:.1f}% of catalog"),
    ("TV Shows",      f"{(df['type']=='TV Show').sum():,}",  f"{(df['type']=='TV Show').mean()*100:.1f}% of catalog"),
    ("Countries",     f"{df['country'].dropna().str.split(',').explode().str.strip().nunique():,}", "production origins"),
    ("Year Span",     f"{year_range[0]}–{year_range[1]}",    "selected window"),
]
for col, (title, value, sub) in zip([col1,col2,col3,col4,col5], kpis):
    with col:
        st.markdown(f"""
        <div class="metric-card">
            <h4>{title}</h4>
            <h2>{value}</h2>
            <p>{sub}</p>
        </div>""", unsafe_allow_html=True)

st.divider()
st.info("👈 Use the **sidebar filters** to slice the data, then navigate the pages below.")

pages = {
    "📊 EDA & Overview":        "pages/1_EDA.py",
    "🎭 Genre Analysis":         "pages/2_Genres.py",
    "🌍 Geography":              "pages/3_Geography.py",
    "🤖 ML Models":              "pages/4_Models.py",
    "💡 Insights":               "pages/5_Insights.py",
}

col_a, col_b, col_c, col_d, col_e = st.columns(5)
for col, (label, _) in zip([col_a,col_b,col_c,col_d,col_e], pages.items()):
    with col:
        st.markdown(f"**{label}**")
