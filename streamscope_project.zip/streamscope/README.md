# 🎬 StreamScope — Netflix Content Strategy Analyzer

A fully interactive Streamlit dashboard analyzing Netflix's global content catalog.
Built on the **Netflix Movies & TV Shows** Kaggle dataset (~8,800 titles).

---

## 📁 Project Structure

```
streamscope/
├── app.py                  # Main entry point + global filters
├── requirements.txt
├── data/                   # Dataset goes here (auto-created)
│   └── netflix_titles.csv
├── pages/
│   ├── 1_EDA.py            # EDA & Overview (Milestone 2)
│   ├── 2_Genres.py         # Genre analysis (Milestone 2)
│   ├── 3_Geography.py      # Country-level analysis (Milestone 2)
│   ├── 4_Models.py         # K-Means + Classifier (Milestone 3)
│   └── 5_Insights.py       # Strategic insights (Milestone 4)
└── utils/
    ├── __init__.py
    └── data_loader.py      # Data loading, cleaning, feature engineering
```

---

## ⚡ Quick Start

### 1. Clone / copy this project
```bash
cd streamscope
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv .venv
source .venv/bin/activate        # Mac/Linux
.venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Get the dataset

**Option A — Kaggle CLI (recommended)**
```bash
# Install Kaggle CLI and configure your API key:
# https://www.kaggle.com/docs/api#authentication
kaggle datasets download -d shivamb/netflix-shows --unzip -p data/
```

**Option B — Manual download**
1. Go to https://www.kaggle.com/datasets/shivamb/netflix-shows
2. Download `netflix_titles.csv`
3. Place it at `data/netflix_titles.csv`

**Option C — Auto-generated sample**
If neither option is done, the app automatically generates a realistic 2,000-title
synthetic dataset so you can explore all features immediately.

### 5. Run the dashboard
```bash
streamlit run app.py
```

Open http://localhost:8501 in your browser.

---

## 🧩 Modules & Milestones

| Page | Milestone | What it covers |
|------|-----------|---------------|
| Home (`app.py`) | 1 | KPIs, global sidebar filters |
| 1 – EDA | 2 | Content growth, ratings, duration, type split |
| 2 – Genres | 2 | Top genres, trends, heatmap, Movie vs TV profiles |
| 3 – Geography | 2 | World map, country rankings, regional genre prefs |
| 4 – ML Models | 3 | K-Means clustering, Random Forest / GB classifier, confusion matrix, CV |
| 5 – Insights | 4 | Synthesized strategic findings, summary stats |

---

## 🛠️ Tech Stack

| Layer | Tools |
|-------|-------|
| Language | Python 3.9+ |
| Data | pandas, numpy |
| Visualization | plotly |
| ML | scikit-learn (KMeans, RandomForest, GradientBoosting, PCA) |
| Dashboard | Streamlit |
| Dataset | Kaggle – shivamb/netflix-shows |

---

## 🚀 Deployment

**Streamlit Community Cloud (free)**
1. Push this folder to a GitHub repo
2. Go to https://share.streamlit.io → New app
3. Set main file path: `app.py`
4. Add `data/netflix_titles.csv` to the repo (or use Kaggle secret in Settings)

**Heroku / Railway / Render**
Add a `Procfile`:
```
web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
```

---

## 📝 Dataset Citation
Bansal, S. (2021). Netflix Movies and TV Shows. Kaggle.
https://www.kaggle.com/datasets/shivamb/netflix-shows
