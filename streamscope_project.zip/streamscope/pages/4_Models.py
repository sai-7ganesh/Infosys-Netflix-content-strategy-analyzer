"""
Page 4 – ML Models
Milestone 3: K-Means clustering, Random Forest classification, feature importance.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (classification_report, confusion_matrix,
                              accuracy_score, f1_score)
from sklearn.decomposition import PCA

st.set_page_config(page_title="ML Models – StreamScope", layout="wide")

st.title("🤖 ML Models")
st.caption("Milestone 3 — Clustering, classification, and feature importance")
st.divider()

df = st.session_state.get("df")
if df is None:
    st.warning("Return to the Home page first."); st.stop()


# ── Feature preparation (shared) ────────────────────────────────────────────
@st.cache_data(show_spinner="Preparing ML features…")
def prepare_features(_df):
    ml = _df[["type","duration_int","release_year","rating",
               "primary_country","genre_count","is_mature",
               "is_likely_original","type_label"]].copy()

    for col in ["rating","primary_country"]:
        le = LabelEncoder()
        ml[f"{col}_enc"] = le.fit_transform(ml[col].fillna("Unknown"))

    ml = ml.dropna(subset=["duration_int","release_year"])
    return ml

ml = prepare_features(df)

feature_cols = ["duration_int","release_year","rating_enc",
                "primary_country_enc","genre_count","is_mature","is_likely_original"]
X = ml[feature_cols].values
y = ml["type_label"].values


# ════════════════════════════════════════════════════════════════════════════
# TAB LAYOUT
# ════════════════════════════════════════════════════════════════════════════
tab1, tab2, tab3 = st.tabs(["🔵 Clustering (K-Means)", "🌲 Classification", "📊 Feature Importance"])


# ── TAB 1: K-Means Clustering ────────────────────────────────────────────────
with tab1:
    st.subheader("K-Means Content Clustering")
    st.markdown("Groups Netflix titles into distinct archetypes based on duration, genre count, release year, rating, and maturity.")

    col_a, col_b = st.columns([1,3])
    with col_a:
        k = st.slider("Number of clusters (k)", 2, 8, 4)
        run_cluster = st.button("▶ Run Clustering", type="primary")

    if run_cluster or "cluster_labels" not in st.session_state:
        with st.spinner("Fitting K-Means…"):
            scaler   = StandardScaler()
            X_scaled = scaler.fit_transform(X)
            km       = KMeans(n_clusters=k, random_state=42, n_init=10)
            labels   = km.fit_predict(X_scaled)
            pca      = PCA(n_components=2, random_state=42)
            X_2d     = pca.fit_transform(X_scaled)

        st.session_state["cluster_labels"] = labels
        st.session_state["cluster_pca"]    = X_2d
        st.session_state["cluster_k"]      = k
        st.session_state["cluster_ml_idx"] = ml.index.tolist()

    labels = st.session_state["cluster_labels"]
    X_2d   = st.session_state["cluster_pca"]
    k_used = st.session_state["cluster_k"]
    idx    = st.session_state["cluster_ml_idx"]

    plot_df = pd.DataFrame({
        "PC1": X_2d[:,0], "PC2": X_2d[:,1],
        "Cluster": [f"Cluster {l+1}" for l in labels],
        "Type": ml.loc[idx,"type"].values,
        "Duration": ml.loc[idx,"duration_int"].values,
        "Year": ml.loc[idx,"release_year"].values,
    })

    fig_cl = px.scatter(
        plot_df, x="PC1", y="PC2", color="Cluster",
        symbol="Type", hover_data=["Duration","Year","Type"],
        template="plotly_dark",
        labels={"PC1":"Principal Component 1","PC2":"Principal Component 2"},
        title=f"K-Means Clustering — k={k_used} (PCA projection)",
    )
    fig_cl.update_traces(marker_size=5, marker_opacity=0.7)
    fig_cl.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        margin=dict(l=0,r=0,t=40,b=0),
    )
    st.plotly_chart(fig_cl, use_container_width=True)

    # Cluster summary
    st.subheader("Cluster Profiles")
    ml_copy = ml.loc[idx].copy()
    ml_copy["cluster"] = labels
    summary = ml_copy.groupby("cluster").agg(
        size=("duration_int","count"),
        avg_duration=("duration_int","mean"),
        avg_year=("release_year","mean"),
        movie_pct=("type_label","mean"),
        mature_pct=("is_mature","mean"),
        avg_genre_count=("genre_count","mean"),
    ).reset_index()
    summary["movie_pct"]       = (summary["movie_pct"]*100).round(1)
    summary["mature_pct"]      = (summary["mature_pct"]*100).round(1)
    summary["avg_duration"]    = summary["avg_duration"].round(1)
    summary["avg_year"]        = summary["avg_year"].round(0).astype(int)
    summary["avg_genre_count"] = summary["avg_genre_count"].round(2)
    summary.columns = ["Cluster","Size","Avg Duration","Avg Year",
                        "Movie %","Mature %","Avg Genres"]
    st.dataframe(summary, use_container_width=True)


# ── TAB 2: Classification ─────────────────────────────────────────────────────
with tab2:
    st.subheader("Movie vs TV Show Classifier")
    st.markdown("Predicts whether a title is a Movie or TV Show using Random Forest.")

    col1, col2 = st.columns([1,2])
    with col1:
        model_choice = st.selectbox("Model", ["Random Forest","Gradient Boosting"])
        test_size    = st.slider("Test set size (%)", 10, 40, 20)
        run_model    = st.button("▶ Train Model", type="primary")

    if run_model or "clf_report" not in st.session_state:
        with st.spinner("Training model…"):
            X_tr, X_te, y_tr, y_te = train_test_split(
                X, y, test_size=test_size/100, random_state=42, stratify=y
            )
            scaler2 = StandardScaler()
            X_tr_s  = scaler2.fit_transform(X_tr)
            X_te_s  = scaler2.transform(X_te)

            if model_choice == "Random Forest":
                clf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
            else:
                clf = GradientBoostingClassifier(n_estimators=100, random_state=42)

            clf.fit(X_tr_s, y_tr)
            y_pred = clf.predict(X_te_s)
            cv_scores = cross_val_score(clf, scaler2.transform(X), y, cv=5, scoring="accuracy")

        st.session_state["clf_report"]  = classification_report(y_te, y_pred, output_dict=True)
        st.session_state["clf_cm"]      = confusion_matrix(y_te, y_pred)
        st.session_state["clf_cv"]      = cv_scores
        st.session_state["clf_fi"]      = clf.feature_importances_
        st.session_state["clf_acc"]     = accuracy_score(y_te, y_pred)

    report = st.session_state["clf_report"]
    cm     = st.session_state["clf_cm"]
    cv     = st.session_state["clf_cv"]
    acc    = st.session_state["clf_acc"]

    # Metrics
    m1,m2,m3,m4 = st.columns(4)
    m1.metric("Accuracy",  f"{acc*100:.1f}%")
    m2.metric("Precision", f"{report['weighted avg']['precision']*100:.1f}%")
    m3.metric("Recall",    f"{report['weighted avg']['recall']*100:.1f}%")
    m4.metric("F1 Score",  f"{report['weighted avg']['f1-score']*100:.1f}%")

    st.caption(f"5-fold CV accuracy: {cv.mean()*100:.1f}% ± {cv.std()*100:.1f}%")
    st.divider()

    # Confusion matrix
    col3, col4 = st.columns(2)
    with col3:
        st.markdown("**Confusion Matrix**")
        fig_cm = go.Figure(data=go.Heatmap(
            z=cm, x=["Movie","TV Show"], y=["Movie","TV Show"],
            colorscale=[[0,"#0f0f0f"],[1,"#E50914"]],
            text=cm, texttemplate="%{text}", showscale=False,
        ))
        fig_cm.update_layout(
            template="plotly_dark",
            plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
            xaxis_title="Predicted", yaxis_title="Actual",
            margin=dict(l=0,r=0,t=10,b=0),
        )
        st.plotly_chart(fig_cm, use_container_width=True)

    with col4:
        st.markdown("**Per-class Metrics**")
        pr_df = pd.DataFrame({
            "Class":     ["Movie","TV Show"],
            "Precision": [report["1"]["precision"], report["0"]["precision"]],
            "Recall":    [report["1"]["recall"],    report["0"]["recall"]],
            "F1":        [report["1"]["f1-score"],  report["0"]["f1-score"]],
        })
        for c in ["Precision","Recall","F1"]:
            pr_df[c] = (pr_df[c]*100).round(1)
        st.dataframe(pr_df, use_container_width=True, hide_index=True)

        cv_df = pd.DataFrame({"Fold": range(1,6), "Accuracy (%)": (cv*100).round(2)})
        st.markdown("**Cross-validation scores**")
        st.dataframe(cv_df, use_container_width=True, hide_index=True)


# ── TAB 3: Feature Importance ────────────────────────────────────────────────
with tab3:
    st.subheader("Feature Importance")
    st.markdown("Which features most strongly predict whether a title is a Movie vs TV Show?")

    if "clf_fi" not in st.session_state:
        st.info("Train the classifier in the Classification tab first.")
    else:
        fi   = st.session_state["clf_fi"]
        fi_df = pd.DataFrame({
            "Feature":    feature_cols,
            "Importance": fi,
        }).sort_values("Importance", ascending=False)
        fi_df["Importance_pct"] = (fi_df["Importance"] / fi_df["Importance"].sum() * 100).round(1)
        fi_df["Feature"] = fi_df["Feature"].str.replace("_enc","").str.replace("_"," ").str.title()

        fig_fi = px.bar(
            fi_df, x="Importance_pct", y="Feature", orientation="h",
            color="Importance_pct",
            color_continuous_scale=["#330000","#E50914"],
            labels={"Importance_pct":"Importance (%)","Feature":""},
            template="plotly_dark", text="Importance_pct",
        )
        fig_fi.update_traces(texttemplate="%{text}%", textposition="outside")
        fig_fi.update_layout(
            plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
            coloraxis_showscale=False,
            yaxis={"categoryorder":"total ascending"},
            margin=dict(l=0,r=0,t=10,b=0),
        )
        st.plotly_chart(fig_fi, use_container_width=True)

        st.markdown("#### Key Takeaways")
        top_feat = fi_df.iloc[0]["Feature"]
        top_imp  = fi_df.iloc[0]["Importance_pct"]
        st.info(f"**{top_feat}** is the single most important feature ({top_imp}%), confirming that runtime is the clearest signal distinguishing movies from TV shows.")
