"""
Page 1 – EDA & Overview
Milestone 2: Content growth, ratings distribution, duration analysis, type split.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

st.set_page_config(page_title="EDA – StreamScope", layout="wide")

st.title("📊 Exploratory Data Analysis")
st.caption("Milestone 2 — Content growth, ratings, duration, and type distribution")
st.divider()

df = st.session_state.get("df")
if df is None:
    st.warning("Return to the Home page first so filters load."); st.stop()

# ── 1. Content growth over time ──────────────────────────────────────────────
st.subheader("Content Added Over Time")

growth = df.groupby(["year_added","type"]).size().reset_index(name="count")
growth = growth.dropna(subset=["year_added"])
growth["year_added"] = growth["year_added"].astype(int)

fig_growth = px.area(
    growth, x="year_added", y="count", color="type",
    color_discrete_map={"Movie":"#E50914","TV Show":"#4a90d9"},
    labels={"year_added":"Year Added","count":"Titles","type":"Type"},
    template="plotly_dark",
)
fig_growth.update_layout(
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    legend=dict(orientation="h", yanchor="bottom", y=1.02),
    hovermode="x unified", margin=dict(l=0,r=0,t=10,b=0),
)
st.plotly_chart(fig_growth, use_container_width=True)

st.divider()

# ── 2. Ratings + Type split ──────────────────────────────────────────────────
col1, col2 = st.columns([3, 2])

with col1:
    st.subheader("Rating Distribution")
    rating_order = ["TV-MA","TV-14","TV-PG","TV-G","TV-Y7","TV-Y","R","PG-13","PG","G","NR","UR"]
    ratings = (df["rating"].value_counts()
               .reindex([r for r in rating_order if r in df["rating"].values])
               .dropna().reset_index())
    ratings.columns = ["rating","count"]
    ratings["pct"] = (ratings["count"] / ratings["count"].sum() * 100).round(1)

    fig_rating = px.bar(
        ratings, x="rating", y="count", text="pct",
        color="count",
        color_continuous_scale=["#4a1a1a","#E50914"],
        labels={"count":"Titles","rating":"Rating"},
        template="plotly_dark",
    )
    fig_rating.update_traces(texttemplate="%{text}%", textposition="outside")
    fig_rating.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        coloraxis_showscale=False, margin=dict(l=0,r=0,t=10,b=0),
    )
    st.plotly_chart(fig_rating, use_container_width=True)

with col2:
    st.subheader("Content Type Split")
    type_counts = df["type"].value_counts().reset_index()
    type_counts.columns = ["type","count"]

    fig_pie = px.pie(
        type_counts, names="type", values="count",
        color="type",
        color_discrete_map={"Movie":"#E50914","TV Show":"#4a90d9"},
        hole=0.55, template="plotly_dark",
    )
    fig_pie.update_traces(textinfo="percent+label", pull=[0.03, 0])
    fig_pie.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        showlegend=False, margin=dict(l=0,r=0,t=10,b=0),
    )
    st.plotly_chart(fig_pie, use_container_width=True)

st.divider()

# ── 3. Duration distribution ─────────────────────────────────────────────────
st.subheader("Duration Distribution")

col3, col4 = st.columns(2)

movies = df[(df["type"]=="Movie") & df["duration_int"].notna()]
shows  = df[(df["type"]=="TV Show") & df["duration_int"].notna()]

with col3:
    st.markdown("**Movie runtime (minutes)**")
    fig_mov = px.histogram(
        movies, x="duration_int", nbins=40,
        color_discrete_sequence=["#E50914"],
        labels={"duration_int":"Runtime (min)","count":"Titles"},
        template="plotly_dark",
    )
    fig_mov.add_vline(x=movies["duration_int"].median(), line_dash="dash",
                      line_color="#fbb040", annotation_text=f"Median: {movies['duration_int'].median():.0f} min")
    fig_mov.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        margin=dict(l=0,r=0,t=10,b=0), bargap=0.05,
    )
    st.plotly_chart(fig_mov, use_container_width=True)

with col4:
    st.markdown("**TV Show seasons**")
    season_counts = shows["duration_int"].value_counts().sort_index().reset_index()
    season_counts.columns = ["seasons","count"]
    season_counts = season_counts[season_counts["seasons"] <= 15]
    fig_tv = px.bar(
        season_counts, x="seasons", y="count",
        color_discrete_sequence=["#4a90d9"],
        labels={"seasons":"Seasons","count":"Titles"},
        template="plotly_dark",
    )
    fig_tv.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        margin=dict(l=0,r=0,t=10,b=0),
    )
    st.plotly_chart(fig_tv, use_container_width=True)

st.divider()

# ── 4. Content length category ───────────────────────────────────────────────
st.subheader("Content Length Categories (Derived Feature)")

lcat = df["length_category"].value_counts().reset_index()
lcat.columns = ["category","count"]

fig_cat = px.bar(
    lcat, x="count", y="category", orientation="h",
    color="count", color_continuous_scale=["#333","#E50914"],
    labels={"count":"Titles","category":""},
    template="plotly_dark",
    text="count",
)
fig_cat.update_traces(textposition="outside")
fig_cat.update_layout(
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    coloraxis_showscale=False, margin=dict(l=0,r=0,t=10,b=0),
    yaxis={"categoryorder":"total ascending"},
)
st.plotly_chart(fig_cat, use_container_width=True)

# ── Raw data preview ─────────────────────────────────────────────────────────
with st.expander("🔍 View raw dataset (first 100 rows)"):
    st.dataframe(df.head(100), use_container_width=True)
