"""
Page 3 – Geography
Milestone 2: Country-level content contributions, regional genre preferences.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Geography – StreamScope", layout="wide")

st.title("🌍 Geography")
st.caption("Milestone 2 — Country-level content analysis and regional preferences")
st.divider()

df = st.session_state.get("df")
if df is None:
    st.warning("Return to the Home page first."); st.stop()

# Explode multi-country rows
country_df = df.assign(country=df["country"].str.split(",")) \
               .explode("country")
country_df["country"] = country_df["country"].str.strip()
country_df = country_df[country_df["country"].notnull() &
                         (country_df["country"] != "Unknown") &
                         (country_df["country"] != "")]

# ── 1. Top countries ──────────────────────────────────────────────────────────
st.subheader("Top Content-Producing Countries")

top_n = st.slider("Show top N countries", 10, 30, 20)
top_countries = country_df["country"].value_counts().head(top_n).reset_index()
top_countries.columns = ["country","count"]
top_countries["pct"] = (top_countries["count"] / len(df) * 100).round(1)

fig_bar = px.bar(
    top_countries, x="count", y="country", orientation="h",
    color="count", color_continuous_scale=["#1a0000","#E50914"],
    labels={"count":"Titles","country":""},
    template="plotly_dark", text="pct",
)
fig_bar.update_traces(texttemplate="%{text}%", textposition="outside")
fig_bar.update_layout(
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    coloraxis_showscale=False,
    yaxis={"categoryorder":"total ascending"},
    margin=dict(l=0,r=0,t=10,b=0),
)
st.plotly_chart(fig_bar, use_container_width=True)

st.divider()

# ── 2. World choropleth ───────────────────────────────────────────────────────
st.subheader("World Map — Content Count")

world = country_df["country"].value_counts().reset_index()
world.columns = ["country","count"]

fig_map = px.choropleth(
    world, locations="country", locationmode="country names",
    color="count", color_continuous_scale="Reds",
    labels={"count":"Titles"},
    template="plotly_dark",
)
fig_map.update_layout(
    paper_bgcolor="#0f0f0f",
    geo=dict(bgcolor="#0f0f0f", showframe=False, showcoastlines=True,
             coastlinecolor="#333", landcolor="#1a1a1a", showocean=True,
             oceancolor="#0a0a0a"),
    margin=dict(l=0,r=0,t=10,b=0),
    coloraxis_colorbar=dict(title="Titles"),
)
st.plotly_chart(fig_map, use_container_width=True)

st.divider()

# ── 3. Country × Content type ────────────────────────────────────────────────
st.subheader("Movie vs TV Show Ratio by Country")

top15 = country_df["country"].value_counts().head(15).index.tolist()
ct_type = (country_df[country_df["country"].isin(top15)]
           .groupby(["country","type"]).size()
           .reset_index(name="count"))
total = ct_type.groupby("country")["count"].transform("sum")
ct_type["pct"] = (ct_type["count"] / total * 100).round(1)

fig_ct = px.bar(
    ct_type, x="pct", y="country", color="type", orientation="h",
    color_discrete_map={"Movie":"#E50914","TV Show":"#4a90d9"},
    labels={"pct":"Share (%)","country":"","type":"Type"},
    template="plotly_dark", barmode="stack",
)
fig_ct.update_layout(
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    yaxis={"categoryorder":"total ascending"},
    legend=dict(orientation="h", yanchor="bottom", y=1.02),
    margin=dict(l=0,r=0,t=30,b=0),
)
st.plotly_chart(fig_ct, use_container_width=True)

st.divider()

# ── 4. Regional genre preferences ────────────────────────────────────────────
st.subheader("Regional Genre Preferences")

top5_countries = country_df["country"].value_counts().head(5).index.tolist()
selected_countries = st.multiselect(
    "Select countries", options=top15, default=top5_countries[:4]
)

if selected_countries:
    rg = country_df[country_df["country"].isin(selected_countries)].copy()
    rg = rg.explode("genre_list").rename(columns={"genre_list":"genre"})
    rg = rg[rg["genre"].str.strip() != ""]
    top_genres_global = rg["genre"].value_counts().head(8).index.tolist()
    rg_filtered = rg[rg["genre"].isin(top_genres_global)]
    rg_grouped = rg_filtered.groupby(["country","genre"]).size().reset_index(name="count")
    total_per_country = rg_grouped.groupby("country")["count"].transform("sum")
    rg_grouped["pct"] = (rg_grouped["count"] / total_per_country * 100).round(1)

    fig_rg = px.bar(
        rg_grouped, x="genre", y="pct", color="country", barmode="group",
        labels={"pct":"Share (%)","genre":"Genre","country":"Country"},
        template="plotly_dark",
    )
    fig_rg.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        xaxis_tickangle=-35,
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        margin=dict(l=0,r=0,t=30,b=0),
    )
    st.plotly_chart(fig_rg, use_container_width=True)

st.divider()

# ── 5. Country stats table ────────────────────────────────────────────────────
with st.expander("📋 Detailed country statistics"):
    stats = (country_df.groupby("country").agg(
        titles=("show_id","count"),
        movies=("type", lambda x: (x=="Movie").sum()),
        tv_shows=("type", lambda x: (x=="TV Show").sum()),
        avg_release_year=("release_year","mean"),
        mature_pct=("is_mature","mean"),
    ).reset_index())
    stats["movie_pct"]   = (stats["movies"] / stats["titles"] * 100).round(1)
    stats["mature_pct"]  = (stats["mature_pct"] * 100).round(1)
    stats["avg_release_year"] = stats["avg_release_year"].round(0).astype("Int64")
    stats = stats.sort_values("titles", ascending=False).head(30)
    st.dataframe(stats, use_container_width=True)
