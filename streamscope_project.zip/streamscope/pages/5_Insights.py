"""
Page 5 – Insights
Milestone 4: Synthesized strategic findings from the Netflix dataset analysis.
"""

import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Insights – StreamScope", layout="wide")

st.title("💡 Strategic Insights")
st.caption("Milestone 4 — Key findings from EDA, clustering, and classification")
st.divider()

df = st.session_state.get("df")
if df is None:
    st.warning("Return to the Home page first."); st.stop()

# ── Compute live stats ─────────────────────────────────────────────────────
movie_pct = (df["type"] == "Movie").mean() * 100
top_genre = df.explode("genre_list")["genre_list"].value_counts().index[0]
top_country = (df["country"].str.split(",").explode().str.strip()
               .value_counts().index[0])
mature_pct = df["is_mature"].mean() * 100
peak_year = int(df.groupby("year_added").size().idxmax()) if df["year_added"].notna().any() else "N/A"
likely_orig_pct = df["is_likely_original"].mean() * 100
avg_duration_movie = df[df["type"]=="Movie"]["duration_int"].median()
top_rating = df["rating"].value_counts().index[0]

insights = [
    {
        "emoji": "📈",
        "title": f"Peak content addition: {peak_year}",
        "body": f"Netflix added the most content in **{peak_year}**, reflecting its aggressive global expansion phase. The platform grew from a few hundred titles to thousands within a decade.",
        "color": "#E50914",
    },
    {
        "emoji": "🎬",
        "title": f"Movies dominate at {movie_pct:.1f}%",
        "body": f"Nearly **{movie_pct:.0f}%** of the catalog is movies, yet TV Shows drive significantly higher engagement per title due to binge-watch mechanics.",
        "color": "#f5763a",
    },
    {
        "emoji": "🌍",
        "title": f"'{top_genre}' is the #1 genre",
        "body": f"**{top_genre}** leads the catalog, underscoring Netflix's strategy to localize content for non-English markets across South Asia, East Asia, and Europe.",
        "color": "#4a90d9",
    },
    {
        "emoji": "🏆",
        "title": f"{top_country} leads content production",
        "body": f"**{top_country}** produces the largest share of Netflix content, though its relative dominance has declined as international content investment grows.",
        "color": "#5ba85a",
    },
    {
        "emoji": "🔞",
        "title": f"{mature_pct:.0f}% of content is mature-rated",
        "body": f"**{mature_pct:.0f}%** of titles carry TV-MA or R ratings. The top rating overall is **{top_rating}**, targeting Netflix's core 18–34 demographic.",
        "color": "#9b59b6",
    },
    {
        "emoji": "⏱️",
        "title": f"Median movie runtime: {avg_duration_movie:.0f} minutes",
        "body": f"Movies cluster tightly around **{avg_duration_movie:.0f} minutes**, with duration being the strongest ML predictor of content type — more important than genre or country.",
        "color": "#fbb040",
    },
    {
        "emoji": "🚀",
        "title": f"{likely_orig_pct:.0f}% likely original/day-one content",
        "body": f"Approximately **{likely_orig_pct:.0f}%** of titles were added to Netflix within one year of their release, serving as a proxy for original or exclusive content strategy.",
        "color": "#1abc9c",
    },
    {
        "emoji": "🤖",
        "title": "4 distinct content archetypes (K-Means)",
        "body": "Clustering reveals four archetypal content groups: **Short kids content**, **Feature dramas**, **Binge-worthy serial TV**, and **Niche documentary/stand-up** — each with unique engagement profiles.",
        "color": "#e74c3c",
    },
]

# Render insight cards
for i in range(0, len(insights), 2):
    col1, col2 = st.columns(2)
    for col, ins in zip([col1, col2], insights[i:i+2]):
        with col:
            st.markdown(f"""
            <div style="background:#1a1a1a; border-radius:12px; padding:20px 22px;
                        border-left:4px solid {ins['color']}; margin-bottom:16px;">
                <div style="font-size:28px; margin-bottom:8px;">{ins['emoji']}</div>
                <div style="font-size:15px; font-weight:600; color:#fff; margin-bottom:8px;">
                    {ins['title']}
                </div>
                <div style="font-size:13px; color:#aaa; line-height:1.6;">
                    {ins['body']}
                </div>
            </div>
            """, unsafe_allow_html=True)

st.divider()

# ── Quick stats table ─────────────────────────────────────────────────────────
st.subheader("Summary Statistics")

col_a, col_b = st.columns(2)

with col_a:
    st.markdown("**Content Breakdown**")
    summary = pd.DataFrame({
        "Metric": ["Total titles","Movies","TV Shows","Unique genres",
                   "Unique countries","Year range"],
        "Value":  [
            f"{len(df):,}",
            f"{(df['type']=='Movie').sum():,} ({movie_pct:.1f}%)",
            f"{(df['type']=='TV Show').sum():,} ({100-movie_pct:.1f}%)",
            f"{df.explode('genre_list')['genre_list'].nunique()}",
            f"{df['country'].str.split(',').explode().str.strip().nunique()}",
            f"{int(df['release_year'].min())}–{int(df['release_year'].max())}",
        ]
    })
    st.dataframe(summary, use_container_width=True, hide_index=True)

with col_b:
    st.markdown("**Rating Distribution**")
    rd = df["rating"].value_counts().head(8).reset_index()
    rd.columns = ["Rating","Count"]
    rd["Share (%)"] = (rd["Count"] / rd["Count"].sum() * 100).round(1)
    st.dataframe(rd, use_container_width=True, hide_index=True)

st.divider()

# ── Content growth mini-chart ─────────────────────────────────────────────────
st.subheader("Content Growth Trajectory")
growth = df.groupby("year_added").size().reset_index(name="count").dropna()
growth["year_added"] = growth["year_added"].astype(int)
fig = px.bar(
    growth, x="year_added", y="count",
    color="count", color_continuous_scale=["#1a0000","#E50914"],
    labels={"year_added":"Year","count":"Titles Added"},
    template="plotly_dark",
)
fig.update_layout(
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    coloraxis_showscale=False, margin=dict(l=0,r=0,t=10,b=0),
)
st.plotly_chart(fig, use_container_width=True)
