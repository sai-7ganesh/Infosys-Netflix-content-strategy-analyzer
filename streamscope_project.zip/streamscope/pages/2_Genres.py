"""
Page 2 – Genre Analysis
Milestone 2: Genre distribution, trends over time, Movie vs TV Show genre profiles.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Genres – StreamScope", layout="wide")

st.title("🎭 Genre Analysis")
st.caption("Milestone 2 — Genre popularity, trends, and content-type genre profiles")
st.divider()

df = st.session_state.get("df")
if df is None:
    st.warning("Return to the Home page first."); st.stop()

# ── Explode genres ────────────────────────────────────────────────────────────
genre_df = df.explode("genre_list").rename(columns={"genre_list":"genre"})
genre_df = genre_df[genre_df["genre"].str.strip() != ""]

# ── 1. Top genres overall ────────────────────────────────────────────────────
st.subheader("Top 15 Genres (All Content)")

top_genres = genre_df["genre"].value_counts().head(15).reset_index()
top_genres.columns = ["genre","count"]

fig_top = px.bar(
    top_genres, x="count", y="genre", orientation="h",
    color="count", color_continuous_scale=["#330000","#E50914"],
    labels={"count":"Titles","genre":""},
    template="plotly_dark", text="count",
)
fig_top.update_traces(textposition="outside")
fig_top.update_layout(
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    coloraxis_showscale=False,
    yaxis={"categoryorder":"total ascending"},
    margin=dict(l=0,r=0,t=10,b=0),
)
st.plotly_chart(fig_top, use_container_width=True)

st.divider()

# ── 2. Genre trend over time ──────────────────────────────────────────────────
st.subheader("Genre Trend Over Years")

top10 = genre_df["genre"].value_counts().head(10).index.tolist()
trend_select = st.multiselect(
    "Select genres to compare",
    options=top10, default=top10[:5],
)

if trend_select:
    trend = (genre_df[genre_df["genre"].isin(trend_select)]
             .groupby(["year_added","genre"]).size()
             .reset_index(name="count")
             .dropna(subset=["year_added"]))
    trend["year_added"] = trend["year_added"].astype(int)

    fig_trend = px.line(
        trend, x="year_added", y="count", color="genre",
        markers=True,
        labels={"year_added":"Year Added","count":"Titles","genre":"Genre"},
        template="plotly_dark",
    )
    fig_trend.update_layout(
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        hovermode="x unified", margin=dict(l=0,r=0,t=30,b=0),
    )
    st.plotly_chart(fig_trend, use_container_width=True)

st.divider()

# ── 3. Movies vs TV genre comparison ─────────────────────────────────────────
st.subheader("Genre Profile: Movies vs TV Shows")

col1, col2 = st.columns(2)

with col1:
    movie_genres = (genre_df[genre_df["type"]=="Movie"]["genre"]
                    .value_counts().head(10).reset_index())
    movie_genres.columns = ["genre","count"]
    fig_m = px.bar(movie_genres, x="count", y="genre", orientation="h",
                   color_discrete_sequence=["#E50914"],
                   labels={"count":"Titles","genre":""},
                   template="plotly_dark", text="count")
    fig_m.update_traces(textposition="outside")
    fig_m.update_layout(
        title="Top Movie Genres",
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        yaxis={"categoryorder":"total ascending"},
        margin=dict(l=0,r=0,t=40,b=0),
    )
    st.plotly_chart(fig_m, use_container_width=True)

with col2:
    tv_genres = (genre_df[genre_df["type"]=="TV Show"]["genre"]
                 .value_counts().head(10).reset_index())
    tv_genres.columns = ["genre","count"]
    fig_tv = px.bar(tv_genres, x="count", y="genre", orientation="h",
                    color_discrete_sequence=["#4a90d9"],
                    labels={"count":"Titles","genre":""},
                    template="plotly_dark", text="count")
    fig_tv.update_traces(textposition="outside")
    fig_tv.update_layout(
        title="Top TV Show Genres",
        plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
        yaxis={"categoryorder":"total ascending"},
        margin=dict(l=0,r=0,t=40,b=0),
    )
    st.plotly_chart(fig_tv, use_container_width=True)

st.divider()

# ── 4. Genre heatmap (top genres × year) ────────────────────────────────────
st.subheader("Genre × Year Heatmap")

top8 = genre_df["genre"].value_counts().head(8).index.tolist()
heat = (genre_df[genre_df["genre"].isin(top8)]
        .groupby(["year_added","genre"]).size()
        .reset_index(name="count")
        .dropna(subset=["year_added"]))
heat["year_added"] = heat["year_added"].astype(int)
pivot = heat.pivot(index="genre", columns="year_added", values="count").fillna(0)

fig_heat = go.Figure(data=go.Heatmap(
    z=pivot.values, x=pivot.columns.tolist(), y=pivot.index.tolist(),
    colorscale=[[0,"#0f0f0f"],[0.5,"#660000"],[1,"#E50914"]],
    hoverongaps=False,
))
fig_heat.update_layout(
    template="plotly_dark",
    plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f",
    xaxis_title="Year Added", yaxis_title="",
    margin=dict(l=0,r=0,t=10,b=0),
)
st.plotly_chart(fig_heat, use_container_width=True)

# ── 5. Genre count per title ─────────────────────────────────────────────────
with st.expander("Genre diversity per title"):
    gc = df["genre_count"].value_counts().sort_index().reset_index()
    gc.columns = ["n_genres","count"]
    fig_gc = px.bar(gc, x="n_genres", y="count",
                    color_discrete_sequence=["#fbb040"],
                    labels={"n_genres":"Number of genres per title","count":"Titles"},
                    template="plotly_dark")
    fig_gc.update_layout(plot_bgcolor="#0f0f0f", paper_bgcolor="#0f0f0f")
    st.plotly_chart(fig_gc, use_container_width=True)
    st.caption(f"Average genres per title: **{df['genre_count'].mean():.2f}**")
